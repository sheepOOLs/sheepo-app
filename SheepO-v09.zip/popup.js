const userList = document.getElementById('user-list');

// Insert your access token here (generated manually from Azure AD or other secure source)
const accessToken = 'eyJ0eXAiOiJKV1QiLCJub25jZSI6IkRTTXRKbWRFckkyMlREaThXMno1djhtZlAzREZHQWptelMxMUsxSkdtZE0iLCJhbGciOiJSUzI1NiIsIng1dCI6IkpZaEFjVFBNWl9MWDZEQmxPV1E3SG4wTmVYRSIsImtpZCI6IkpZaEFjVFBNWl9MWDZEQmxPV1E3SG4wTmVYRSJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC82MTNhMTljNS0wNzFhLTQxOTQtOTE0MC0zZDU3NjYwMDI0YjcvIiwiaWF0IjoxNzU0NDI0NzI0LCJuYmYiOjE3NTQ0MjQ3MjQsImV4cCI6MTc1NDUxMTQyNCwiYWNjdCI6MCwiYWNyIjoiMSIsImFjcnMiOlsicDEiXSwiYWlvIjoiQVpRQWEvOFpBQUFBWC9oMTNoZWhkR3FpR2lvWkEzTUZqVmozYlZGdDBuRHBSNlIvUEUxMGloTGcxYmtyeWlIMWhsbXZWZHEwdGtYRjVpQjJwWmYvWWthNm5LMXcxT2JBc0hjZXFJSnA2UXZuL2o3WTBLZENRYXZ2U3grRTg2NEVCUzlYWWNzMnh1dGljOFNyZlJQd1ZLT2o4aGNYOEdLaVJBb3piOFYrZnZsTGF2R1p2Mk53RWhjdE9Va3k0VFB2YnlLSStQMDhXeGJNIiwiYW1yIjpbInB3ZCIsInJzYSIsIm1mYSJdLCJhcHBfZGlzcGxheW5hbWUiOiJHcmFwaCBFeHBsb3JlciIsImFwcGlkIjoiZGU4YmM4YjUtZDlmOS00OGIxLWE4YWQtYjc0OGRhNzI1MDY0IiwiYXBwaWRhY3IiOiIwIiwiZGV2aWNlaWQiOiJhMzA5Zjk1NS0wYWFhLTQzMDctYWU2ZS02MDRiYzNmZjA0NzgiLCJmYW1pbHlfbmFtZSI6IlBpcmFjaGEiLCJnaXZlbl9uYW1lIjoiTXVoYW1tYWQiLCJpZHR5cCI6InVzZXIiLCJpcGFkZHIiOiI3MS4xOTEuMjA5Ljk5IiwibmFtZSI6Ik11aGFtbWFkIFBpcmFjaGEiLCJvaWQiOiJiNzdjNjVkOS0xNDgzLTQ4MjEtYmE3ZS04MjJmZDEwZTIyODgiLCJwbGF0ZiI6IjMiLCJwdWlkIjoiMTAwMzIwMDA0MURBNzY1QiIsInJoIjoiMS5BUndBeFJrNllSb0hsRUdSUUQxWFpnQWt0d01BQUFBQUFBQUF3QUFBQUFBQUFBRE1BZGdjQUEuIiwic2NwIjoiRGlyZWN0b3J5LlJlYWQuQWxsIG9wZW5pZCBwcm9maWxlIFVzZXIuUmVhZCBlbWFpbCBVc2VyLlJlYWQuQWxsIiwic2lkIjoiMDA1YzdmYzktMTIyYS1kMGI1LTBlNjAtMjhlZGUzOWE4ZGYyIiwic2lnbmluX3N0YXRlIjpbImR2Y19tbmdkIiwiZHZjX2NtcCIsImttc2kiXSwic3ViIjoiSTN0eGhHVGd6ZzNBYmg2ZjQtek05dlc0NllvQVZ1azhFelVwMUlsb1NvWSIsInRlbmFudF9yZWdpb25fc2NvcGUiOiJOQSIsInRpZCI6IjYxM2ExOWM1LTA3MWEtNDE5NC05MTQwLTNkNTc2NjAwMjRiNyIsInVuaXF1ZV9uYW1lIjoibXVoYW1tYWQucGlyYWNoYUBrbm93bWFkaWNzLmNvbSIsInVwbiI6Im11aGFtbWFkLnBpcmFjaGFAa25vd21hZGljcy5jb20iLCJ1dGkiOiI3SVliNjJPcTZFV2R1NDJxRnVFcUFBIiwidmVyIjoiMS4wIiwid2lkcyI6WyI2MmU5MDM5NC02OWY1LTQyMzctOTE5MC0wMTIxNzcxNDVlMTAiLCJiNzlmYmY0ZC0zZWY5LTQ2ODktODE0My03NmIxOTRlODU1MDkiXSwieG1zX2NjIjpbIkNQMSJdLCJ4bXNfZnRkIjoicmlsTnFoTGN4R0hmZjQwbUJfRU9ISEhKM3VPU2lXRVY2T25XQjVaWW9ENEJkWE4zWlhOME15MWtjMjF6IiwieG1zX2lkcmVsIjoiMTYgMSIsInhtc19zc20iOiIxIiwieG1zX3N0Ijp7InN1YiI6IkNtSFg3cHZVZkFvWnRHclhOQW03alhTOFd0WVc4ZlI5UDdSNDZPWk9WazQifSwieG1zX3RjZHQiOjE0ODYxNjI5Nzd9.XOPgo-XD38M7VZkzguYy7Rw-TTbn2fYUkTei8cKzk1l3-xTTbH0UjhY1gm6PTeKbCC5wZ7d70JWqA0QWR4XmJMsS9QdhTC_8ppSU1IztAWkkL0bSwM_A-1Rvie03rOhc5Pc5Rwt_3Rc8a6lookcjuYAf6jIRRrFpYzV_tZCOVpCJCFinIBiMT2Kt6Oph9fNswT1jUgbQfX8ed5l3i5L4iDc732jCcEwV_xpPcY5Hv7UEKSuzCQI74d92pFRG2_u2aBtyRW_cM_uBaK2SVEA0YG_60KM9j83A_6287lnbGzA0uaiH36Jkjp8NBXfKeoHNfoHX2cZzI4B8t3XLuBDlgg'; // Replace with actual token

document.addEventListener('DOMContentLoaded', () => {
  console.log("Popup loaded, using direct access token...");
  fetchUsers(accessToken);
});

function fetchUsers(token) {
  console.log("Fetching users with token:", token);

  fetch('https://graph.microsoft.com/v1.0/users?$select=displayName,mail', {
    headers: {
      'Authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    }
  })
    .then(response => {
      console.log("Graph API response status:", response.status);
      return response.json();
    })
    .then(data => {
      console.log("Graph API data:", data);
      userList.innerHTML = '';
      if (data.value && data.value.length > 0) {
        data.value.forEach(user => {
          const li = document.createElement('li');
          li.textContent = `${user.displayName || 'No Name'} (${user.mail || 'No Email'})`;
          userList.appendChild(li);
        });
      } else {
        userList.innerHTML = '<li>No users found.</li>';
      }
    })
    .catch(err => {
      console.error("Fetch error:", err);
      userList.innerHTML = `<li>Error: ${err.message}</li>`;
    });
}

// access-token: IVF8Q~z8~is8Pnt6DSVSfBV9RXoBZ7yRz9w9ta_C
// 8h48Q~Y2fzVkeqGCVpfEje3Ep8m.63I3hXSsJb_s