// Required for OAuth2 login using chrome.identity (nothing needed for now)
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: "page.html" });
});
