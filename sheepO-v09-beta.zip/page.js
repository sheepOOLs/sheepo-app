const clientId = 'e7e86df6-fbdc-49bc-804a-89de20611093'; //11m  kmi:'887e3262-5cbf-43eb-b0ac-6f14cf45af4f'; // O365 Users - Replace with your Azure AD app client ID
    const tenantId = 'f65f4f4a-5b18-4266-b286-d0c0dd1a24ed'; //'613a19c5-071a-4194-9140-3d57660024b7';
    const scopes = 'https://graph.microsoft.com/User.Read.All https://graph.microsoft.com/Directory.Read.All';
    const redirectUri = chrome.identity.getRedirectURL('page.html');// window.location.origin + window.location.pathname;
      //const redirectUri = "extension://eghahpiebfifadbmjmfjknbblaakhehn/page.html" ;//+ window.location.pathname;
      const userList = document.getElementById('user-list');

    function getAccessToken() {
// `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      userList.innerHTML += "<br>Getting access token...<br>";
      chrome.identity.launchWebAuthFlow({
      url: `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize` +
          `?client_id=${encodeURIComponent(clientId)}` +
          `&response_type=token` +         
          `&redirect_uri=${encodeURIComponent(redirectUri)}` + 
          `&scope=${encodeURIComponent('openid profile User.Read')}` +
          `&response_mode=fragment`,
      interactive: true
    }, (responseUrl) => {
            userList.innerHTML += "<br>return...<br>";
            userList.innerHTML += "<br>" + responseUrl + "<br>";
      if (chrome.runtime.lastError) {
              userList.innerHTML += "<br>error...<br>";
        userList.innerHTML += `<li>Error: ${chrome.runtime.lastError.message}</li>`;
        console.error('Auth flow error:', chrome.runtime.lastError);
        //return;
      }

  
      if (!responseUrl) {
        console.error('Empty response URL from WebAuthFlow');
        return;
      }

      // Extract the hash fragment (after '#')
      const fragment = responseUrl.split('#')[1] || '';
      const params = new URLSearchParams(fragment);

      if (params.has('error')) {
        console.error('OAuth error:', params.get('error'), params.get('error_description'));
        return;
      }

      const accessToken = params.get('access_token');
      const tokenType = params.get('token_type');
      const expiresIn = params.get('expires_in');

      if (accessToken) {
        console.log('Access Token:', accessToken);
        console.log('Token Type:', tokenType);
        console.log('Expires In (sec):', expiresIn);
        // You can store it for later use
        //chrome.storage.local.set({ accessToken, tokenType, expiresIn });

        userList.innerHTML += "<br>" + accessToken + "<br>";
        userList.innerHTML += "<br>" + tokenType + "<br>";
        userList.innerHTML += "<br>" + expiresIn + "<br>";
      } else {
        console.error('No access_token found in OAuth response');
      }
    });

    }

    // function extractAccessTokenFromUrl() {
    //   const hash = window.location.hash;
    //   if (!hash.includes('access_token')) return null;
    //   const params = new URLSearchParams(hash.substring(1));
    //   return params.get('access_token');
    // }

    function fetchUsers(token) {
      const apiUrl = 'https://graph.microsoft.com/v1.0/users?$select=displayName,mail';
      const userList = document.getElementById('user-list');

      fetch(apiUrl, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      })
      .then(res => res.json())
      .then(data => {
        userList.innerHTML = '';
        if (!data.value || data.value.length === 0) {
          userList.innerHTML = '<li>No users found.</li>';
          return;
        }
        data.value.forEach(user => {
          const name = user.displayName || 'No Name';
          const email = user.mail || 'No Email';
          const li = document.createElement('li');
          li.textContent = `${name} (${email})`;
          userList.appendChild(li);
        });
      })
      .catch(err => {
        console.error("Error fetching users:", err);
        userList.innerHTML = `<li>Error: ${err.message}</li>`;
      });
    }

    document.addEventListener('DOMContentLoaded', () => {
    
      userList.innerHTML = redirectUri;
      getAccessToken();
      // const token = extractAccessTokenFromUrl();
      // if (token) {
      //   history.replaceState(null, '', redirectUri); // Clean up URL
      //   fetchUsers(token);
      // } else {
      //   getAccessToken();
      // }
    });